<?php

return[
    'driver' => "mysql",
    'host' => "localhost",
    'database_name' => "lesson01",
    'username' => "root",
    'password' => ""
];

