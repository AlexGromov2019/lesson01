<?php

namespace App\exception;

use Exception;

class NotEnoughMoneyException extends Exception {

}