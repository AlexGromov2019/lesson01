<?php

namespace App\exception;

use Exception;

class AccountisBlockedException extends Exception {

}
