<?php $this->layout('layout', ['title' => 'Views About']) ?>

<h1><?=$this->e($name)?>: Views About</h1>
<p>Hello! Views About</p>
