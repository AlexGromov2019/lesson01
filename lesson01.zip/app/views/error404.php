<?php $this->layout('layout', ['title' => 'Error 404']); ?>

<div class="col-sm-8">
        <article class="single-blog">
            <div class="post-content">
                <img src="../assets/images/error404.jpg" style="margin-bottom: 40px;">
                <h2 align="center"><span style="color: #3c763d;">We recommend that you go to the</span>
                    <a href="/" style="text-decoration: underline;">Main Page</a></h2>
            </div>

        </article>
</div>


